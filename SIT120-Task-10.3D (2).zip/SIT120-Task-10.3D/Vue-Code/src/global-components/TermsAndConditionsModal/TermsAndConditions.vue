<script setup>
import './terms-and-conditions.css'
import { ref, defineProps } from 'vue';

const props = defineProps({
    modalId: String,
});

const modalId = ref(props.modalId).value;
</script>

<template>
    <div class="modal fade" :id="modalId" data-bs-backdrop="static" data-bs-keyboard="false"
        tabindex="-1" aria-labelledby="termsAndConditionsLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="termsAndConditionsLabel">Terms and Conditions</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <h4>Terms of Service</h4>
                    <p>- I am who I say I am</p>
                    <p>- I am not impersonating another person with these details</p>
                    <p>- I am not to use any of the messaging systems on this website to spread hate speech,
                        misinformation or abuse</p>
                    <p>- I am aware that if I breach any of these terms of service, my profile will be blacklisted
                        and
                        my services
                        will be denied</p>
                    <h4>Terms of Delivery</h4>
                    <p>- I am not liable for any refunds for my delivery if I provide incorrect information</p>
                    <p>- I am not a member of another supermarket company trying to buy out all our products</p>
                    <p>- I am not using another person's banking details to fraudualently purchase products from
                        this
                        website</p>
                    <p>- I am aware that if I breach any of these terms of delivery, either my profile will be
                        blacklisted and my services will be denied or my order will be denied and I will not receive
                        a
                        refund</p>
                </div>
            </div>
        </div>
    </div>
</template>