<script setup>
import './checkout.css'
import CheckoutPurchase from './CheckoutPurchase.vue';
import CheckoutExtra from './CheckoutPurchase.vue';
import CheckoutProduct from './Product/CheckoutProduct.vue';

import { ref, defineProps } from 'vue';

const products = [
    {
        productId: "0",
        productName: "Cheese and Bacon Shapes",
        price: 3.99,
        selectedOption: "",
        unselectedOptions: null,
        disabledSelect: true,
        quantity: 1,
        imgSrc: '/images/cheese-and-bacon-shapes.jpg',
        imgAlt: 'cheese and bacon shapes'
    },
    {
        productId: "1",
        productName: "A2 Milk",
        price: 0.99,
        selectedOption: "",
        unselectedOptions: {
            "1": 'option 1',
            "2": 'option 2',
            "3": 'option 3',
            "4": 'option 4'
        },
        disabledSelect: false,
        quantity: 2,
        imgSrc: '/images/milk.jpg',
        imgAlt: 'milk'
    }]

function getProductData(productData) {
    // console.log(productData.productId.value)
    for (var i = 0; i < products.length; i++) {
        if (products[i].productId == productData.productId.value) {
            products[i].selectedOption = productData.returnOption
            products[i].quantity = productData.returnQuantity
            console.log(products[i].selectedOption + ", " + products[i].quantity)
        }
    }
}

function validatePurchase(returnData) {
    console.log("Javascript function")
    // console.log(products)
    // Validate products
    var returnStatement = true;
    for (var i = 0; i < products.length; i++) {
        const product = products[i]

        if (product.unselectedOptions != null) {
            if (product.selectedOption == "") {
                document.getElementById("optionInput-" + i + "-large").className = "form-control border-0 is-invalid optionInput-" + i + "-large";
                document.getElementById("optionInput-" + i + "-small").className = "form-control border-0 is-invalid optionInput-" + i + "-small";
                document.getElementById("optionMessage-" + i + "-large").innerHTML = "Please enter an option for your product"
                document.getElementById("optionMessage-" + i + "-small").innerHTML = "Please enter an option for your product"
                document.getElementById("optionMessage-" + i + "-large").className = "text-danger optionMessage-" + i + "-large";
                document.getElementById("optionMessage-" + i + "-small").className = "text-danger optionMessage-" + i + "-small";
                returnStatement = false;
            }
            else {
                document.getElementById("optionInput-" + i + "-large").className = "form-control border-0 is-valid optionInput-" + i + "-large";
                document.getElementById("optionInput-" + i + "-small").className = "form-control border-0 is-valid optionInput-" + i + "-small";
                document.getElementById("optionMessage-" + i + "-large").innerHTML = "Option input is correct"
                document.getElementById("optionMessage-" + i + "-small").innerHTML = "Option input is correct"
                document.getElementById("optionMessage-" + i + "-large").className = "text-success optionMessage-" + i + "-large";
                document.getElementById("optionMessage-" + i + "-small").className = "text-success optionMessage-" + i + "-small";
            }
        }

        if (product.quantity <= 0) {
            document.getElementById("quantityInput-" + i + "-large").className = "form-control border-0 is-invalid optionInput-" + i + "-large";
            document.getElementById("quantityInput-" + i + "-small").className = "form-control border-0 is-invalid optionInput-" + i + "-small";
            document.getElementById("quantityMessage-" + i + "-large").innerHTML = "Please enter an option for your product"
            document.getElementById("quantityMessage-" + i + "-small").innerHTML = "Please enter an option for your product"
            document.getElementById("quantityMessage-" + i + "-large").className = "text-danger optionMessage-" + i + "-large";
            document.getElementById("quantityMessage-" + i + "-small").className = "text-danger optionMessage-" + i + "-small";
            returnStatement = false;
        }
        else {
            document.getElementById("quantityInput-" + i + "-large").className = "form-control border-0 is-valid optionInput-" + i + "-large";
            document.getElementById("quantityInput-" + i + "-small").className = "form-control border-0 is-valid optionInput-" + i + "-small";
            document.getElementById("quantityMessage-" + i + "-large").innerHTML = "Option input is correct"
            document.getElementById("quantityMessage-" + i + "-small").innerHTML = "Option input is correct"
            document.getElementById("quantityMessage-" + i + "-large").className = "text-success optionMessage-" + i + "-large";
            document.getElementById("quantityMessage-" + i + "-small").className = "text-success optionMessage-" + i + "-small";
        }
    }


    //Validate purchase
    const firstName = returnData.returnFirstName
    const lastName = returnData.returnLastName
    const email = returnData.returnEmail
    const phone = returnData.returnPhone
    const address = returnData.returnAddress
    const suburb = returnData.returnSuburb
    const state = returnData.returnState
    const postcode = returnData.returnPostcode
    const card = returnData.returnCardNumber
    const security = returnData.returnSecurityCode
    const expiryMonth = returnData.returnExpiryMonth
    const expiryYear = returnData.returnExpiryYear
    const collectInput = returnData.returnCollectInput
    const termsAndConditions = returnData.returnTermsAndConditions
    const privacyPolicy = returnData.returnPrivacyPolicy
    console.log(collectInput)
    console.log(termsAndConditions)
    console.log(privacyPolicy)

    var phonePattern = /[0-9]{10}/;
    var securityPattern = /[0-9]{3}/;
    var postcodePattern = /[0-9]{4}/;
    var cardPattern = /[0-9]{16}/;
    console.log(securityPattern)
    if (firstName == "") {
        document.getElementById("firstnameInput").className = "form-control is-invalid";
        document.getElementById("firstnameMessage").innerHTML = "Please enter your first name"
        document.getElementById("firstnameMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("firstnameInput").className = "form-control is-valid";
        document.getElementById("firstnameMessage").innerHTML = "First name is correct"
        document.getElementById("firstnameMessage").className = "text-success"
    }

    if (lastName == "") {
        document.getElementById("lastnameInput").className = "form-control is-invalid";
        document.getElementById("lastnameMessage").innerHTML = "Please enter your last name"
        document.getElementById("lastnameMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("lastnameInput").className = "form-control is-valid";
        document.getElementById("lastnameMessage").innerHTML = "Last name is correct"
        document.getElementById("lastnameMessage").className = "text-success"
    }

    var emailFormat =/@/;
    if (email == "") {
        document.getElementById("emailInput").className = "form-control is-invalid";
        document.getElementById("emailMessage").innerHTML = "Please enter your email address"
        document.getElementById("emailMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (emailFormat.test(email) == false)
    {
        document.getElementById("emailInput").className = "form-control is-invalid";
        document.getElementById("emailMessage").innerHTML = "Your email address has invalid format"
        document.getElementById("emailMessage").className = "text-danger"
        returnStatement = false;   
    }
    else {
        document.getElementById("emailInput").className = "form-control is-valid";
        document.getElementById("emailMessage").innerHTML = "Email input is correct"
        document.getElementById("emailMessage").className = "text-success"
    }

    if (phone == "") {
        document.getElementById("phoneInput").className = "form-control is-invalid";
        document.getElementById("phoneMessage").innerHTML = "Please enter your phone number"
        document.getElementById("phoneMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (phone.length != 10) {
        document.getElementById("phoneInput").className = "form-control is-invalid";
        document.getElementById("phoneMessage").innerHTML = "Phone has an invalid length"
        document.getElementById("phoneMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (phonePattern.test(phone) == false) {
        leftoverCharacters = phone.replace(/([0-9])/gi, '');
        document.getElementById("phoneInput").className = "form-control is-invalid";
        document.getElementById("phoneMessage").innerHTML = "Contains characters '" + leftoverCharacters + "'. Numbers only!"
        document.getElementById("phoneMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("phoneInput").className = "form-control is-valid";
        document.getElementById("phoneMessage").innerHTML = "Phone number input is correct"
        document.getElementById("phoneMessage").className = "text-success"
    }




    if (address == "") {
        document.getElementById("addressInput").className = "form-control is-invalid";
        document.getElementById("addressMessage").innerHTML = "Please enter your address correctly"
        document.getElementById("addressMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("addressInput").className = "form-control is-valid";
        document.getElementById("addressMessage").innerHTML = "Address input is correct"
        document.getElementById("addressMessage").className = "text-success"
    }

    if (suburb == "") {
        document.getElementById("suburbInput").className = "form-control is-invalid";
        document.getElementById("suburbMessage").innerHTML = "Please enter your suburb correctly"
        document.getElementById("suburbMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("suburbInput").className = "form-control is-valid";
        document.getElementById("suburbMessage").innerHTML = "Suburb input is correct"
        document.getElementById("suburbMessage").className = "text-success"
    }

    if (state == "") {
        document.getElementById("stateInput").className = "form-control is-invalid";
        document.getElementById("stateMessage").innerHTML = "Please enter your state correctly"
        document.getElementById("stateMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("stateInput").className = "form-control is-valid";
        document.getElementById("stateMessage").innerHTML = "State input is correct"
        document.getElementById("stateMessage").className = "text-success"
    }

    if (postcode == "") {
        document.getElementById("postcodeInput").className = "form-control is-invalid";
        document.getElementById("postcodeMessage").innerHTML = "Please enter your postcode correctly"
        document.getElementById("postcodeMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (postcode.length != 4) {
        document.getElementById("postcodeInput").className = "form-control is-invalid";
        document.getElementById("postcodeMessage").innerHTML = "Postcode has an invalid length"
        document.getElementById("postcodeMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (postcodePattern.test(postcode) == false) {
        leftoverCharacters = postcode.replace(/([0-9])/gi, '');
        document.getElementById("postcodeInput").className = "form-control is-invalid";
        document.getElementById("postcodeMessage").innerHTML = "Contains characters '" + leftoverCharacters + "'. Numbers only!"
        document.getElementById("postcodeMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("postcodeInput").className = "form-control is-valid";
        document.getElementById("postcodeMessage").innerHTML = "Type input is correct"
        document.getElementById("postcodeMessage").className = "text-success"
    }




    if (card == "") {
        document.getElementById("cardInput").className = "form-control is-invalid";
        document.getElementById("cardMessage").innerHTML = "Please enter your card number correctly"
        document.getElementById("cardMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (card.length != 16) {
        document.getElementById("cardInput").className = "form-control is-invalid";
        document.getElementById("cardMessage").innerHTML = "Card number has an invalid length"
        document.getElementById("cardMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (cardPattern.test(card) == false) {
        leftoverCharacters = card.replace(/([0-9])/gi, '');
        document.getElementById("cardInput").className = "form-control is-invalid";
        document.getElementById("cardMessage").innerHTML = "Contains characters '" + leftoverCharacters + "'. Numbers only!"
        document.getElementById("cardMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("cardInput").className = "form-control is-valid";
        document.getElementById("cardMessage").innerHTML = "Card number input is correct"
        document.getElementById("cardMessage").className = "text-success"
    }

    if (security == "") {
        document.getElementById("securityInput").className = "form-control is-invalid";
        document.getElementById("securityMessage").innerHTML = "Please enter your security code correctly"
        document.getElementById("securityMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (security.length != 3) {
        document.getElementById("securityInput").className = "form-control is-invalid";
        document.getElementById("securityMessage").innerHTML = "Security code number has an invalid length"
        document.getElementById("securityMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (securityPattern.test(security) == false) {
        leftoverCharacters = security.replace(/([0-9])/gi, '');
        document.getElementById("securityInput").className = "form-control is-invalid";
        document.getElementById("securityMessage").innerHTML = "Contains characters '" + leftoverCharacters + "'. Numbers only!"
        document.getElementById("securityMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("securityInput").className = "form-control is-valid";
        document.getElementById("securityMessage").innerHTML = "Security code input is correct"
        document.getElementById("securityMessage").className = "text-success"
    }

    if (expiryMonth == "") {
        document.getElementById("expiryMonthInput").className = "form-control is-invalid";
        document.getElementById("expiryMessage").innerHTML = "Please enter your expiry date correctly"
        document.getElementById("expiryMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (expiryMonth > 12 || expiryMonth < 1) {
        document.getElementById("expiryMonthInput").className = "form-control is-invalid";
        document.getElementById("expiryMessage").innerHTML = "Please enter your expiry date correctly"
        document.getElementById("expiryMessage").className = "text-danger"
        returnStatement = false;
    }
    else if ((expiryMonth <= 12 || expiryMonth >= 1) && (expiryYear <= 31 || expiryYear >= 1)) {
        document.getElementById("expiryMonthInput").className = "form-control is-valid";
        document.getElementById("expiryYearInput").className = "form-control is-valid";
        document.getElementById("expiryMessage").innerHTML = "Expiry date is correct"
        document.getElementById("expiryMessage").className = "text-success"
    }

    if (expiryYear == "") {
        document.getElementById("expiryYearInput").className = "form-control is-invalid";
        document.getElementById("expiryMessage").innerHTML = "Please enter your expiry date correctly"
        document.getElementById("expiryMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (expiryYear > 31 || expiryYear < 1) {
        document.getElementById("expiryMonthInput").className = "form-control is-invalid";
        document.getElementById("expiryMessage").innerHTML = "Please enter your expiry date correctly"
        document.getElementById("expiryMessage").className = "text-danger"
        returnStatement = false;
    }

    if (collectInput == "") {
        document.getElementById("collectInput1").className = "form-check-input is-invalid";
        document.getElementById("collectInput2").className = "form-check-input is-invalid";
        document.getElementById("collectInputMessage").innerHTML = "Please enter an input"
        document.getElementById("collectInputMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("collectInput1").className = "form-check-input is-valid";
        document.getElementById("collectInput2").className = "form-check-input is-valid";
        document.getElementById("collectInputMessage").innerHTML = "Input is valid"
        document.getElementById("collectInputMessage").className = "text-success"
    }

    if (termsAndConditions == "") {
        document.getElementById("termsConditionsInput").className = "form-check-input is-invalid";
        returnStatement = false;
    }
    else {
        document.getElementById("termsConditionsInput").className = "form-check-input is-valid";
    }

    if (privacyPolicy == "") {
        document.getElementById("privacyPolicyInput").className = "form-check-input is-invalid";
        returnStatement = false;
    }
    else {
        document.getElementById("privacyPolicyInput").className = "form-check-input is-valid";
    }

    if (privacyPolicy == "" || termsAndConditions == "")
    {
        document.getElementById("agreementMessage").innerHTML = "Please agree to the following"
        document.getElementById("agreementMessage").className = "text-danger"
    }
    else
    {
        document.getElementById("agreementMessage").innerHTML = "Agreed"
        document.getElementById("agreementMessage").className = "text-success"
    }

    if (returnStatement == true) {
        console.log("Validation complete")
        document.location.href = "/"
    }
}

</script>

<template>
    <img id="page-banner" class="col-12 img-fluid" src="/images/banner-4.jpg" alt="banner">
    <div class="container-fluid p-0">
        <div class="m-0 text-white" id="title">
            <!-- <div id="header-space"></div> -->
            <h1 class="font-weight-light text-center m-0 py-4">Checkout</h1>
        </div>

        <!--Each row here contains an item. In the future, if a person clicks on the 'X', I will consider adding a message box asking the user if they would like to remove the item from the cart.-->
        <div v-for="product in products" id="products-section">
            <CheckoutProduct :productId=product.productId :productName=product.productName :price=product.price
                :disabledSelect=product.disabledSelect :selectedOption=product.selectedOption
                :unselectedOptions=product.unselectedOptions :quantity=product.quantity :imgSrc=product.imgSrc :imgAlt="product.imgAlt"
                class="product" @product-data="getProductData" />
        </div>
        <div id="total-cost" class="m-0 p-0">
            <h2 class="font-weight-light text-white text-center">Total Cost:</h2>
            <h3 class="text-white font-weight-light text-center m-0 pb-4">$10.99</h3>
        </div>
        <!-- Form details. For now, I have added no validation, as this is a draft, however I will add it in a future task -->
        <!-- I will consider replacing the floating labels with other labels in the future. For now, I will leave them here and consider making adjustments in task 7.4D-->
        <CheckoutPurchase @submit-data="validatePurchase"/>
    </div>
</template>