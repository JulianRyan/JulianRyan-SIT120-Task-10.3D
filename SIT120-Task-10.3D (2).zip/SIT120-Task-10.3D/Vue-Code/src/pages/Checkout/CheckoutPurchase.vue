<script setup>
import './checkout.css'
import { ref, defineProps, defineEmits } from 'vue';

// const props = defineProps({
//     firstName: String,
//     lastName: String,
//     email: String,
//     phone: String,
//     address: String,
//     suburb: String,
//     state: String,
//     postcode: String,
//     cardNumber: String,
//     securityCode: String,
//     expiryMonth: Number,
//     expiryYear: Number
// });

const firstName = ref("")
const lastName = ref("")
const email = ref("")
const phone = ref("")
const address = ref("")
const suburb = ref("")
const state = ref("")
const postcode = ref("")
const cardNumber = ref("")
const securityCode = ref("")
const expiryMonth = ref("")
const expiryYear = ref("")
const collectInput = ref("")
const termsAndConditions = ref("")
const privacyPolicy = ref("")

// const emit = defineEmits(['update-made']);

const emit = defineEmits(['submit-data']);

function sendForValidation() {
    const returnData = {
        returnFirstName: String,
        returnLastName: String,
        returnEmail: String,
        returnPhone: String,
        returnAddress: String,
        returnSuburb: String,
        returnState: String,
        returnPostcode: String,
        returnCardNumber: String,
        returnSecurityCode: String,
        returnExpiryMonth: Number,
        returnExpiryYear: Number,
        returnCollectInput: String,
        returnPrivacyPolicy: Boolean,
        returnTermsAndConditions: Boolean
    };
    returnData.returnFirstName = firstName.value
    returnData.returnLastName = lastName.value
    returnData.returnEmail = email.value
    returnData.returnPhone = phone.value
    returnData.returnAddress = address.value
    returnData.returnSuburb = suburb.value
    returnData.returnState = state.value
    returnData.returnPostcode = postcode.value
    returnData.returnCardNumber = cardNumber.value
    returnData.returnSecurityCode = securityCode.value
    returnData.returnExpiryMonth = expiryMonth.value
    returnData.returnExpiryYear = expiryYear.value
    returnData.returnCollectInput = collectInput.value
    returnData.returnPrivacyPolicy = privacyPolicy.value
    returnData.returnTermsAndConditions = termsAndConditions.value
    // console.log(collectInput)
    // console.log(termsAndConditions)
    // console.log(privacyPolicy)
    emit('submit-data', returnData);
}
</script>

<template>

    <form @submit.prevent="validatePurchase" class="container-fluid m-0 p-0" id="payment-details">
        <!--Contact details are the first name, last name, email and phone number-->
        <!-- Text boxes requring numbers have type 'text' because of issues with the 'maxlength' variable. The email should count as an input with a modifier. -->
        <div class="row px-0 mx-0">
            <div class="col-sm-1 col-md-1 col-lg-1"></div>
            <div class="col-sm-10 col-md-10 col-lg-10">
                <h2 class="font-weight-light text-center pb-0 pt-4 text-white">Contact Details</h2>
                <div class="row">
                    <div class="col-sm-6 mb-4">
                        <label for="firstnameInput" class="text-white">First Name</label>
                        <input type="text" class="form-control border-0" id="firstnameInput" placeholder="First Name"
                            v-model="firstName" required>
                        <div id="firstnameMessage"></div>
                    </div>

                    <div class="col-sm-6 mb-4">
                        <label for="lastnameInput" class="text-white">Last Name</label>
                        <input type="text" class="form-control border-0" id="lastnameInput" placeholder="Last Name"
                            v-model="lastName" required>
                        <div id="lastnameMessage"></div>
                    </div>
                </div>
                <div class="row pb-2">
                    <div class="col-sm-6 mb-4">
                        <label for="emailInput" class="text-white">Email</label>
                        <input type="email" class="form-control border-0" id="emailInput" placeholder="Email"
                            v-model="email" required>
                        <div id="emailMessage"></div>
                    </div>
                    <!--An example where floating labels can be an issue.-->
                    <div class="col-sm-6 mb-4">
                        <label for="phoneInput" class="text-white">Mobile</label>
                        <div class="input-group" id="mobileDiv">
                            <span class="input-group-text border-0" id="mobileAddon">+61</span>
                            <input type="text" placeholder="xxxx xxx xxx" class="form-control border-0" id="phoneInput"
                                maxlength="10" aria-describedby="mobileAddon" pattern="[0-9]{10}" v-model="phone"
                                required>
                        </div>
                        <div id="phoneMessage"></div>
                    </div>
                </div>

                <!--Location details include a street address, a suburb, a state and a postcode.-->
                <h2 class="font-weight-light text-center py-0 text-white">Location Details</h2>
                <div class="row">
                    <div class="col-sm-6 mb-4">
                        <label for="addressInput" class="text-white">Address</label>
                        <input type="text" class="form-control border-0" id="addressInput" placeholder="Address"
                            v-model="address" required>
                        <div id="addressMessage"></div>
                    </div>

                    <div class="col-sm-6 mb-4">
                        <label for="suburbInput" class="text-white">Suburb</label>
                        <input type="text" class="form-control border-0" id="suburbInput" placeholder="Suburb"
                            v-model="suburb" required>
                        <div id="suburbMessage"></div>
                    </div>
                </div>
                <div class="row mb-4">
                    <div class="col-sm-6 mb-4">
                        <label for="stateInput" class="text-white">State</label>
                        <select type="text" class="form-control border-0" id="stateInput" placeholder="" value=""
                            v-model="state" required>
                            <option selected value="" disabled>Choose...</option>
                            <option value="WA">WA</option>
                            <option value="NT">NT</option>
                            <option value="SA">SA</option>
                            <option value="QLD">QLD</option>
                            <option value="NSW">NSW</option>
                            <option value="ACT">ACT</option>
                            <option value="VIC">VIC</option>
                            <option value="TAS">TAS</option>
                        </select>
                        <div id="stateMessage"></div>
                    </div>

                    <div class="col-sm-6 mb-4">
                        <label for="postcodeInput" class="text-white">Postcode</label>
                        <input type="text" class="form-control border-0" id="postcodeInput" maxlength="4"
                            pattern="[0-9]{4}" placeholder="Postcode" v-model="postcode" required>
                        <div id="postcodeMessage"></div>
                    </div>
                </div>

                <!--Banking details-->
                <div class="row mb-4">
                    <h2 class="font-weight-light text-center py-0 text-white">Credit Card Details</h2>
                    <div class="col-lg-6 mb-4">
                        <label for="cardInput" class="text-white">Card Number</label>
                        <input type="text" class="form-control border-0" id="cardInput"
                            placeholder="XXXX XXXX XXXX XXXX" pattern="[0-9]{16}" maxlength="16" v-model="cardNumber"
                            required>
                        <div id="cardMessage"></div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 mb-4">
                        <label for="securityInput" class="text-white">Security Code</label>
                        <input type="text" class="form-control border-0" id="securityInput" placeholder="XXX"
                            pattern="[0-9]{3}" maxlength="3" v-model="securityCode" required>
                        <div id="securityMessage"></div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 mb-4">
                        <label for="expiryDiv" class="text-white">Expiry Date</label>
                        <div class="input-group border-0" id="expiryDiv">
                            <input type="text" placeholder="MM" class="form-control" id="expiryMonthInput" maxlength="2"
                                aria-describedby="cardExpiryAddon" pattern="[0-9]{2}" v-model="expiryMonth" required>
                            <span class="input-group-text border-0" id="cardExpiryAddon">/</span>
                            <input type="text" placeholder="DD" class="form-control" id="expiryYearInput" maxlength="2"
                                aria-describedby="cardExpiryAddon" pattern="[0-9]{2}" v-model="expiryYear" required>
                        </div>
                        <div id="expiryMessage"></div>
                    </div>
                </div>
            </div>
            <div class="col-sm-1 col-md-1 col-lg-1"></div>
            <!--Purchases the order and links back to the Home Page-->
        </div>
        <div class="row mb-4 text-white px-0 mx-0">
            <h2 class="font-weight-light text-center py-0 text-white">Final Details</h2>
            <div class="col-lg-4 col-md-3 col-sm-2"></div>
            <div class="col-lg-4 col-md-6 col-sm-8">
                <label for="collect-options" class="mb-2">Please select your delivery mode:</label>
                <div class="mb-4" id="collect-options">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="collect-option" id="collectInput1" v-model="collectInput">
                        <label class="form-check-label ps-1" for="collectInput1" value="address" required>
                            Deliver to my address
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="collect-option" id="collectInput2" v-model="collectInput">
                        <label class="form-check-label ps-1" for="collectInput2" value="counter" required>
                            Purchase from counter
                        </label>
                    </div>
                    <div id="collectInputMessage"></div>
                </div>
                <label for="agreements" class="mb-2">Please agree to the following:</label>
                <div class="mb-4" id="agreements">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="termsConditionsInput" v-model="termsAndConditions">
                        <label class="form-check-label ps-1" for="termsConditionsInput" required>
                            I agree that I have read the terms and conditions
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="privacyPolicyInput" v-model="privacyPolicy">
                        <label class="form-check-label ps-1" for="privacyPolicyInput" required>
                            I agree that I have read the privacy policy
                        </label>
                        <div id="agreementMessage"></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-3 col-sm-2"></div>
        </div>
        <div class="text-center mb-4">
            <button type="submit" class="btn p-1 px-2 mx-2 rounded-pill border-0 w-auto" id="submit-order"
                @click="sendForValidation()">
                Submit order
            </button>
        </div>
    </form>
</template>