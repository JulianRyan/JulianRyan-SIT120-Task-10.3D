<script setup>
import { ref, defineProps, defineEmits } from 'vue';
import './checkout-product.css'

const props = defineProps({
    productId: Number,
    size: String,
    productName: String,
    price: Number,
    selectedOption: String,
    unselectedOptions: Array,
    disabledSelect: Boolean,
    quantity: Number
});

const productId = ref(props.productId);
const size = ref(props.size);
const productName = ref(props.productName).value;
const price = ref(props.price).value;
const disabledSelect = ref(props.disabledSelect).value;
const unselectedOptions = ref(props.unselectedOptions).value;
const quantity = ref(props.quantity).value;
const selectedOption = ref(props.selectedOption).value;
const optionId = "optionInput-" + productId.value + "-" + size.value
const quantityId = "quantityInput-" + productId.value + "-" + size.value
const optionMessage = "optionMessage-" + productId.value + "-" + size.value
const quantityMessage = "quantityMessage-" + productId.value + "-" + size.value

const returnData = {
    returnOption: String,
    returnQuantity: Number
};

const returnOption = ref(props.selectedOption)
const returnQuantity = ref(props.quantity)

// const productData = ref({
//     productName = productName,
//     price = price,
//     disabledSelect = disabledSelect,
//     unselectedOptions = unselectedOptions,
//     quantity = quantity,
// })

// const emit = defineEmits(['update-made']);

const emit = defineEmits(['update-made']);

function updateData(returnData) {
    returnData.returnOption = returnOption.value
    returnData.returnQuantity = returnQuantity.value
    emit('update-made', returnData);
}

</script>

<template>
    <div class="col-sm-6 py-3">
        <button type="button" class="btn-close form-control border-0 float-end p-0 mx-0 shadow-none" aria-label="Close"
            id="close-icon">
        </button>
        <div class="text-center mb-2 mt-4 p-2">
            <h3 class="font-weight-light text-center pb-2">{{ productName }}</h3>
            <h5 class="text-center">${{ price }}</h5>
        </div>
        <!-- In some examples, a product may have a 'type'. In this case, there is no type and the
                        type is disabled. -->
        <div class="form">
            <div class="mb-4 px-2">
                <label for="typeInput">Option</label>
                <select type="text" :id=optionId value="" class="form-control border-0 " v-model="returnOption"
                    :disabled=disabledSelect @change="updateData" >
                    <option selected disabled :value='""'>Please enter a value...</option>
                    <option :value=returnValue v-for="(option, returnValue) in unselectedOptions">{{ option }}</option>
                    <!-- <option value="One">Option 1</option>
                    <option value="Two">Option 2</option>
                    <option value="Three">Option 3</option>
                    <option value="Four">...</option> -->
                </select>
                <div :id=optionMessage></div>
            </div>
            <div class="mb-4 px-2">
                <label for="quantityInput">Quantity</label>
                <input type="number" :id=quantityId class="form-control border-0 "
                    placeholder="Please enter a quantity" v-model="returnQuantity" @change="updateData">
                <div :id=quantityMessage></div>
            </div>
        </div>
    </div>
</template>