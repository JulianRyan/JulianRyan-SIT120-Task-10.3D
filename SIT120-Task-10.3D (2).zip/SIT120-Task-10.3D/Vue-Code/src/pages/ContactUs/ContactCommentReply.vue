<script setup>
import './contact-us.css'
import { ref, defineProps } from 'vue';

const props = defineProps({
    replyId: Number,
    firstName: String,
    commentText: String,
    collapseRepliesLink: String
});

const replyId = ref(props.commentId);
const firstName = ref(props.firstName).value;
const commentText = ref(props.commentText).value;

// console.log(firstName)
// console.log(commentText)


</script>

<template>
    <div class="row mb-1">
        <!-- Each comment will contain a list of replies. The user can show or hide replies of each comment -->
        <div class="collapse" :id="collapseRepliesLink">
            <div class="card p-2 reply border-0">
                <h6 class="col-auto">{{ firstName }}</h6>
                <p>{{ commentText }}</p>
            </div>
        </div>
    </div>
</template>