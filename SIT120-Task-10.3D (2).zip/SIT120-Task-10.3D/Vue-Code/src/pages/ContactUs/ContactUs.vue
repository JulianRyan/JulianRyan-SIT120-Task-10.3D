<script setup>
import './contact-us.css'
import ContactComment from './ContactComment.vue';
import TermsAndConditions from '../../global-components/TermsAndConditionsModal/TermsAndConditions.vue';
import PrivacyPolicy from '../../global-components/PrivacyPolicyModal/PrivacyPolicy.vue';
import { ref } from 'vue';

var comments = [
    {
        commentId: 0,
        firstName: "John",
        commentText: "One of my deliveries hasn't delivered yet. How long should it take for my delivery to arrive?",
        replies: [{
            commentId: 0,
            firstName: "Mary",
            commentText: "Hi John, it should take about 2 weeks for it to arrive"
        },
        {
            commentId: 1,
            firstName: "Sean",
            commentText: "Hi John, it usually takes 1-2 weeks to deliver packages to your location. It will arrive soon!"
        }]
    },
    {
        commentId: 1,
        firstName: "Tom",
        commentText: "It appears my toaster isn't working, can I get a refund?",
        replies: []
    },
    {
        commentId: 2,
        firstName: "Jill",
        commentText: "I would like to track the location of my cup I have just ordered",
        replies: []
    }
]

const commentsKey = ref(0)

// Key change method: https://michaelnthiessen.com/force-re-render
const rerenderComments = () => {
    commentsKey.value += 1;
};

function sendComment() {
    if (commentValidation()) {
        // Finding max value from array: https://www.geeksforgeeks.org/how-to-search-the-max-value-of-an-attribute-in-an-array-object/
        // Adds 1 to the largest id
        const newCommentId = comments.reduce((largest, comment) => {
            return (largest = largest > comment.commentId ? largest : comment.commentId);
        }, 0) + 1;
        const newFirstName = document.getElementById("nameInput").value;
        const newComment = document.getElementById("commentInput").value;
        comments.unshift({
            commentId: newCommentId,
            firstName: newFirstName,
            commentText: newComment,
            replies: []
        });
        rerenderComments()
    }
}

function commentValidation() {
    var returnStatement = true;
    const firstName = document.getElementById("nameInput").value;
    const comment = document.getElementById("commentInput").value;
    const email = document.getElementById("emailInput").value;
    const phone = document.getElementById("phoneInput").value;
    var phonePattern = /[0-9]{10}/;
    if (firstName == "" ||
        comment == "" ||
        email == "" ||
        (phone == "" || phone.length != 10 || phonePattern.test(phone) == false)
    ) {
        returnStatement = false;
    }
    if (returnStatement == false) {
        if (firstName == "") {
            document.getElementById("nameInput").className = "form-control is-invalid";
            document.getElementById("nameMessage").innerHTML = "Please enter your first name"
            document.getElementById("nameMessage").className = "text-danger"
        }
        else {
            document.getElementById("nameInput").className = "form-control is-valid";
            document.getElementById("nameMessage").innerHTML = "Name input is correct"
            document.getElementById("nameMessage").className = "text-success"
        }


        if (comment == "") {
            document.getElementById("commentInput").className = "form-control is-invalid";
            document.getElementById("commentMessage").innerHTML = "Please enter a comment"
            document.getElementById("commentMessage").className = "text-danger"
        }
        else {
            document.getElementById("commentInput").className = "form-control is-valid";
            document.getElementById("commentMessage").innerHTML = "Comment input is correct"
            document.getElementById("commentMessage").className = "text-success"
        }


        var emailFormat = /@/;
        if (email == "") {
            document.getElementById("emailInput").className = "form-control is-invalid";
            document.getElementById("emailMessage").innerHTML = "Please enter your email address"
            document.getElementById("emailMessage").className = "text-danger"
            returnStatement = false;
        }
        else if (emailFormat.test(email) == false) {
            document.getElementById("emailInput").className = "form-control is-invalid";
            document.getElementById("emailMessage").innerHTML = "Your email address has invalid format"
            document.getElementById("emailMessage").className = "text-danger"
            returnStatement = false;
        }
        else {
            document.getElementById("emailInput").className = "form-control is-valid";
            document.getElementById("emailMessage").innerHTML = "Email input is correct"
            document.getElementById("emailMessage").className = "text-success"
        }


        if (phone == "") {
            document.getElementById("phoneInput").className = "form-control is-invalid";
            document.getElementById("phoneMessage").innerHTML = "Please enter your phone number"
            document.getElementById("phoneMessage").className = "text-danger"
            returnStatement = false;
        }
        else if (phone.length != 10) {
            document.getElementById("phoneInput").className = "form-control is-invalid";
            document.getElementById("phoneMessage").innerHTML = "Phone has an invalid length"
            document.getElementById("phoneMessage").className = "text-danger"
            returnStatement = false;
        }
        else if (phonePattern.test(phone) == false) {
            leftoverCharacters = phone.replace(/([0-9])/gi, '');
            document.getElementById("phoneInput").className = "form-control is-invalid";
            document.getElementById("phoneMessage").innerHTML = "Contains characters '" + leftoverCharacters + "'. Numbers only!"
            document.getElementById("phoneMessage").className = "text-danger"
            returnStatement = false;
        }
        else {
            document.getElementById("phoneInput").className = "form-control is-valid";
            document.getElementById("phoneMessage").innerHTML = "Phone number input is correct"
            document.getElementById("phoneMessage").className = "text-success"
        }
        document.getElementById("comment-controls").className = "row form mb-4 align-items-center"
    }
    else {
        console.log("message sent")
        document.getElementById("nameInput").className = "form-control";
        document.getElementById("nameMessage").innerHTML = ""
        document.getElementById("nameMessage").className = ""

        document.getElementById("commentInput").className = "form-control";
        document.getElementById("commentMessage").innerHTML = ""
        document.getElementById("commentMessage").className = ""

        document.getElementById("emailInput").className = "form-control";
        document.getElementById("emailMessage").innerHTML = ""
        document.getElementById("emailMessage").className = ""

        document.getElementById("phoneInput").className = "form-control";
        document.getElementById("phoneMessage").innerHTML = ""
        document.getElementById("phoneMessage").className = ""
        document.getElementById("comment-controls").className = "row form mb-4 align-items-end"
    }
    return returnStatement
}
</script>

<template>
    <img id="page-banner" class="col-12 img-fluid" src="/images/banner-4.jpg" alt="banner">

    <!--Details related to the company. I didn't include a map because most websites I know don't actually use maps in their 'contact us' section. -->
    <div class="container-fluid p-0">
        <div class="row font-weight-light text-center pt-4 pb-2 text-white mx-0" id="title">
            <h1>Contact Us</h1>
        </div>
        <!--Contact details are the first name, last name, email and phone number-->
        <div class="row px-0 mx-0" id="company-details">
            <div class="col-0 col-md-1 col-lg-2"></div>
            <div class="col-12 col-md-10 col-lg-8">
                <div class="row text-center pb-2">
                    <h3>Egg-cellent Produce</h3>
                </div>
                <div class="row">
                    <div class="col-md-6 col-12 px-4 pb-4">
                        <h5><strong>Company Email:</strong></h5>
                        <h5>jcryan@deakin.edu.au</h5>
                    </div>
                    <div class="col-md-6 col-12 px-4 pb-4">
                        <h5><strong>Company Phone Number:</strong></h5>
                        <h5>0123 456 789</h5>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-12 px-4">
                        <div class="pb-4">
                            <h5><strong>Company Address:</strong></h5>
                            <h5>20 Johnson St, Richmond</h5>
                        </div>
                        <div class="pb-4">
                            <h5><strong>Open hours:</strong></h5>
                            <h6>Monday: 9am-5pm</h6>
                            <h6>Tuesday: 9am-5pm</h6>
                            <h6>Wednesday: 9am-5pm</h6>
                            <h6>Thursday: 9am-5pm</h6>
                            <h6>Friday: 9am-5pm</h6>
                            <h6>Saturday: 9am-3pm</h6>
                            <h6>Sunday: 9am-3pm</h6>
                        </div>
                        <div class="pb-4">
                            <button type="button" class="btn p-0 text-white" data-bs-toggle="modal"
                                data-bs-target="#termsAndConditionsModal">
                                <h5>
                                    <u>Terms and Conditions</u>
                                </h5>
                            </button>
                            <br>
                            <button type="button" class="btn p-0 text-white" data-bs-toggle="modal"
                                data-bs-target="#privacyPolicyModal">
                                <h5>
                                    <u>Privacy Policy</u>
                                </h5>
                            </button>
                        </div>
                    </div>
                    <div class="col-md-6 col-12 px-4 pb-4">
                        <h5><strong>Company Location:</strong></h5>
                        <img src="/images/map.png" alt="map" class="img-fluid rounded-3">
                    </div>
                </div>
            </div>
            <div class="col-0 col-md-1 col-lg-2"></div>
        </div>
        <div class="row px-0 mx-0" id="faqs">
            <div class="col-0 col-md-1 col-lg-2"></div>
            <div class="col-12 col-md-10 col-lg-8">

                <h1 class="font-weight-light text-center py-1">FAQs</h1>

                <!--An accordion of FAQs. Will add more later when the user stories are done-->
                <div class="container-fluid">
                    <div class="accordion" id="accordionExample">
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    How long will it take for my order to arrive?
                                </button>
                            </h2>
                            <div id="collapseOne" class="accordion-collapse collapse show"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    It usually takes a maximum of 2 weeks for your order to arrive
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    My order hasn't arrived yet. What do I do?
                                </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Send us a message or an email and if it doesn't arrive within 2 weeks of the
                                    order
                                    placement, we
                                    will send you a refund.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                    What time of day should my order arrive?
                                </button>
                            </h2>
                            <div id="collapseThree" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Your order will arrive depending on the time Australia Post usually delivers
                                    packages in
                                    your
                                    state.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-0 col-md-1 col-lg-2"></div>
        </div>
        <div class="row px-0 mx-0" id="comment-section">
            <div class="col-0 col-md-1 col-lg-2"></div>
            <div class="col-12 col-md-10 col-lg-8 px-4">

                <!--The comment section-->
                <div class="mt-5 mb-4 my-4">
                    <div class="form">
                        <label for="commentInput">Feel free to leave us a comment!</label>
                        <textarea class="form-control" id="commentInput" placeholder="Insert comment here"></textarea>
                    </div>
                    <div id="commentMessage"></div>
                </div>

                <!--In the future, the user should be able to send comments using this system-->
                <div class="row form align-items-end mb-4" id="comment-controls">
                    <div class="col-md-6 col-lg-4 col-12 mb-2">
                        <label for="nameInput">First Name</label>
                        <input type="text" class="form-control" id="nameInput" placeholder="Name">
                        <div id="nameMessage"></div>
                    </div>
                    <div class="col-md-6 col-lg-4 col-12 mb-2">
                        <label for="emailInput">Email</label>
                        <input type="email" class="form-control" id="emailInput" placeholder="Name">
                        <div id="emailMessage"></div>
                    </div>
                    <div class="col-md-6 col-lg-4 col-12 mb-2">
                        <label for="phoneInput" class="text-white">Mobile</label>
                        <div class="input-group" id="mobileDiv">
                            <span class="input-group-text border-0" id="mobileAddon">+61</span>
                            <input type="text" placeholder="xxxx xxx xxx" class="form-control border-0" id="phoneInput"
                                maxlength="10" aria-describedby="mobileAddon" pattern="[0-9]{10}" required>
                        </div>
                        <div id="phoneMessage"></div>
                    </div>
                    <div class="col-md-auto col-lg-12 col-12 mb-2 px-0 text-center">
                        <button type="button" class="btn px-2 mx-2 rounded-pill comment-button border-0"
                            data-bs-toggle="collapse" role="button" id="send-comment" @click="sendComment">
                            Send Comment
                        </button>
                    </div>
                </div>

                <!--Comments will display here.-->
                <div class="mb-4">
                    <div class="card" id="comments">
                        <div class="card-body comment border-0">

                            <!-- firstName: "John",
        commentText: "One of my deliveries hasn't delivered yet. How long should it take for my delivery to arrive?",
        replies: -->
                            <div v-for="comment in comments" id="products-section">
                                <ContactComment :commentId=comment.commentId :firstName=comment.firstName
                                    :commentText=comment.commentText :replies=comment.replies :key="commentsKey" />
                                <hr class="contact-comment-hr mx-0">
                            </div>
                            <p class="text-center">No more comments to show</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-0 col-md-1 col-lg-2"></div>
        </div>
    </div>
    <TermsAndConditions :id="'termsAndConditionsModal'"/>
    <PrivacyPolicy :id="'privacyPolicyModal'"/>
</template>