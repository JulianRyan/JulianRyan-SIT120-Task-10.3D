import Home from './pages/Home/Home.vue';
import AboutUs from './pages/AboutUs/AboutUs.vue';
import ArticleCollection from './pages/ArticleCollection/ArticleCollection.vue';
import Checkout from './pages/Checkout/Checkout.vue';
import ContactUs from './pages/ContactUs/ContactUs.vue';
import Product from './pages/Product/Product.vue';
import ProductCollection from './pages/ProductCollection/ProductCollection.vue';
import { createApp } from 'vue'
import './global.css'
import App from './App.vue'

import {createRouter, createWebHistory} from 'vue-router'

const router = createRouter({
    history: createWebHistory(),
    routes:[
        { path: '', component: Home},
        { path: '/about-us', component: AboutUs},
        { path: '/articles', component: ArticleCollection},
        { path: '/checkout', component: Checkout},
        { path: '/contact-us', component: ContactUs},
        { path: '/product', component: Product},
        { path: '/products', component: ProductCollection}
    ]
});

const app= createApp(App)

app.use(router)

app.mount('#app')
