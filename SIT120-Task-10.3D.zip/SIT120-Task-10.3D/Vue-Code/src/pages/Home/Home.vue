<script setup>
import './home.css'
</script>

<template>

    <body>
        <img id="page-banner" class="col-12 img-fluid" src="/images/banner-4.jpg" alt="banner">
        <div id="banner-overlay"></div>

        <!-- List of categories for different products. In the future, when a user selects a category, products shown in the product-collection page will only be from that category. There will be a total list of items -->
        <div class="container-fluid" id="categories">
            <h1 class="font-weight-light text-center text-white pt-4 pb-2">Categories</h1>
            <div class="d-flex flex-row flex-nowrap overflow-auto py-2">
                <div class="card card-block mx-2 col-lg-2 col-md-3 col-sm-4 col-6 text-center">
                    <div class="card-body px-0">
                        <router-link to="/products" class="stretched-link"></router-link>
                        <h3 class="card-title">Meat</h3>
                    </div>
                    <div class="card-footer px-0">
                        <img class="img-fluid" src="/images/meat.jpg" alt="meat">
                    </div>
                </div>
                <div class="card card-block mx-2 col-lg-2 col-md-3 col-sm-4 col-6 text-center">
                    <div class="card-body px-0">
                        <router-link to="/products" class="stretched-link"></router-link>
                        <h3 class="card-title">Dairy</h3>
                    </div>
                    <div class="card-footer px-0">
                        <img class="img-fluid" src="/images/dairy.jpg" alt="dairy">
                    </div>
                </div>
                <div class="card card-block mx-2 col-lg-2 col-md-3 col-sm-4 col-6 text-center">
                    <div class="card-body px-0">
                        <router-link to="/products" class="stretched-link"></router-link>
                        <h3 class="card-title">Fruit</h3>
                    </div>
                    <div class="card-footer px-0">
                        <img class="img-fluid" src="/images/fruit.jpg" alt="fruit">
                    </div>
                </div>
                <div class="card card-block mx-2 col-lg-2 col-md-3 col-sm-4 col-6 text-center">
                    <div class="card-body px-0">
                        <router-link to="/products" class="stretched-link"></router-link>
                        <h3 class="card-title">Vegetables</h3>
                    </div>
                    <div class="card-footer px-0">
                        <img class="img-fluid" src="/images/vegetables.jpg" alt="vegetables">
                    </div>
                </div>
                <div class="card card-block mx-2 col-lg-2 col-md-3 col-sm-4 col-6 text-center">
                    <div class="card-body px-0">
                        <router-link to="/products" class="stretched-link"></router-link>
                        <h3 class="card-title">Bathroom</h3>
                    </div>
                    <div class="card-footer px-0">
                        <img class="img-fluid" src="/images/bathroom.jpg" alt="bathroom">
                    </div>
                </div>
                <div class="card card-block mx-2 col-lg-2 col-md-3 col-sm-4 col-6 text-center">
                    <div class="card-body px-0">
                        <router-link to="/products" class="stretched-link"></router-link>
                        <h3 class="card-title">Desserts</h3>
                    </div>
                    <div class="card-footer px-0">
                        <img class="img-fluid" src="/images/dessert.jpg" alt="dessert">
                    </div>
                </div>
                <div class="card card-block mx-2 col-lg-2 col-md-3 col-sm-4 col-6 text-center">
                    <div class="card-body px-0">
                        <router-link to="/products" class="stretched-link"></router-link>
                        <h3 class="card-title">Snacks</h3>
                    </div>
                    <div class="card-footer px-0">
                        <img class="img-fluid" src="/images/snacks.jpg" alt="snacks">
                    </div>
                </div>
            </div>
        </div>

        <!-- A list of products under a special category. In the future, when a user selects a product, that product shown in the product page will only be that particular product. There will be a total list of items -->
        <div class="container-fluid" id="special-category">
            <h1 class="font-weight-light text-center text-white pt-4 pb-2">Christmas Specials</h1>
            <div class="d-flex flex-row flex-nowrap overflow-auto  py-2">
                <div class="card card-block mx-2 col-lg-3 col-md-4 col-sm-6 col-8 text-center">
                    <div class="card-body">
                        <router-link to="/product" class="stretched-link"></router-link>
                        <h3 class="card-title">Turkey</h3>
                        <h6 class="card-title">Was $9.99/kg</h6>
                        <h4 class="card-title">Now $4.99/kg</h4>
                        <h6 class="card-title">Rating: &#x2605;&#x2605;&#x2605;&#x2606;&#x2606;</h6>
                    </div>
                    <div class="card-footer px-0">
                        <img class="img-fluid" src="/images/turkey.jpg" alt="turkey">
                    </div>
                </div>
                <div class="card card-block mx-2 col-lg-3 col-md-4 col-sm-6 col-8 text-center">
                    <div class="card-body px-0">
                        <router-link to="/product" class="stretched-link"></router-link>
                        <h3 class="card-title">Dressing gown</h3>
                        <h6 class="card-title">Was $24.99/kg</h6>
                        <h4 class="card-title">Now $17.99/kg</h4>
                        <h6 class="card-title">Rating: &#x2605;&#x2605;&#x2605;&#x2606;&#x2606;</h6>
                    </div>
                    <div class="card-footer px-0">
                        <img class="img-fluid" src="/images/dressing-gown.jpg" alt="dressing gown">
                    </div>
                </div>
                <div class="card card-block mx-2 col-lg-3 col-md-4 col-sm-6 col-8 text-center">
                    <div class="card-body px-0">
                        <router-link to="/product" class="stretched-link"></router-link>
                        <h3 class="card-title">Wrapping paper</h3>
                        <h6 class="card-title">Was $1.99/kg</h6>
                        <h4 class="card-title">Now $0.99/kg</h4>
                        <h6 class="card-title">Rating: &#x2605;&#x2605;&#x2605;&#x2606;&#x2606;</h6>
                    </div>
                    <div class="card-footer px-0">
                        <img class="img-fluid" src="/images/wrapping-paper.jpg" alt="wrapping paper">
                    </div>
                </div>
                <div class="card card-block mx-2 col-lg-3 col-md-4 col-sm-6 col-8 text-center">
                    <div class="card-body px-0">
                        <router-link to="/product" class="stretched-link"></router-link>
                        <h3 class="card-title">Train set</h3>
                        <h6 class="card-title">Was $11.99/kg</h6>
                        <h4 class="card-title">Now $5.99/kg</h4>
                        <h6 class="card-title">Rating: &#x2605;&#x2605;&#x2605;&#x2606;&#x2606;</h6>
                    </div>
                    <div class="card-footer px-0">
                        <img class="img-fluid" src="/images/train-set.jpg" alt="train set">
                    </div>
                </div>
                <div class="card card-block mx-2 col-lg-3 col-md-4 col-sm-6 col-8 text-center">
                    <div class="card-body px-0">
                        <router-link to="/product" class="stretched-link"></router-link>
                        <h3 class="card-title">Remote controlled car</h3>
                        <h6 class="card-title">Was $19.99/kg</h6>
                        <h4 class="card-title">Now $11.99/kg</h4>
                        <h6 class="card-title">Rating: &#x2605;&#x2605;&#x2605;&#x2606;&#x2606;</h6>
                    </div>
                    <div class="card-footer px-0">
                        <img class="img-fluid" src="/images/toy-car.jpg" alt="toy car">
                    </div>
                </div>
                <div class="card card-block mx-2 col-lg-3 col-md-4 col-sm-6 col-8 text-center">
                    <div class="card-body px-0">
                        <router-link to="/product" class="stretched-link"></router-link>
                        <h3 class="card-title">Furby</h3>
                        <h6 class="card-title">Was $14.99/kg</h6>
                        <h4 class="card-title">Now $8.99/kg</h4>
                        <h6 class="card-title">Rating: &#x2605;&#x2605;&#x2605;&#x2606;&#x2606;</h6>
                    </div>
                    <div class="card-footer px-0">
                        <img class="img-fluid" src="/images/furby.jpg" alt="furby">
                    </div>
                </div>
                <div class="card card-block mx-2 col-lg-3 col-md-4 col-sm-6 col-8 text-center">
                    <div class="card-body px-0">
                        <router-link to="/product" class="stretched-link"></router-link>
                        <h3 class="card-title">Wallet</h3>
                        <h6 class="card-title">Was $19.99/kg</h6>
                        <h4 class="card-title">Now $11.99/kg</h4>
                        <h6 class="card-title">Rating: &#x2605;&#x2605;&#x2605;&#x2606;&#x2606;</h6>
                    </div>
                    <div class="card-footer px-0">
                        <img class="img-fluid" src="/images/wallet.jpg" alt="wallet">
                    </div>
                </div>
            </div>
        </div>

        <!-- A list of products on sale. In the future, when a user selects a product, that product shown in the product page will only be that particular product. There will be a total list of items. There are no plans to add functionality to change the category after a certain number of days. The category will remain Christmas. -->
        <div class="container-fluid" id="on-special">
            <h1 class="font-weight-light text-center text-white pt-4 pb-2">On Special</h1>
            <div class="d-flex flex-row flex-nowrap overflow-auto  py-2">
                <div class="card card-block mx-2 col-lg-3 col-md-4 col-sm-6 col-8 text-center">
                    <div class="card-body px-0">
                        <router-link to="/product" class="stretched-link"></router-link>
                        <h3 class="card-title">Chicken Drumsticks</h3>
                        <h6 class="card-title">Was $1.99/kg</h6>
                        <h4 class="card-title">Now $0.99/kg</h4>
                        <h6 class="card-title">Rating: &#x2605;&#x2605;&#x2605;&#x2606;&#x2606;</h6>
                    </div>
                    <div class="card-footer px-0">
                        <img class="img-fluid" src="/images/chicken-drumsticks-4.jpg" alt="chicken drumsticks">
                    </div>
                </div>
                <div class="card card-block mx-2 col-lg-3 col-md-4 col-sm-6 col-8 text-center">
                    <div class="card-body px-0">
                        <router-link to="/product" class="stretched-link"></router-link>
                        <h3 class="card-title">2L A2 Milk</h3>
                        <h6 class="card-title">Was $1.99/kg</h6>
                        <h4 class="card-title">Now $0.99/kg</h4>
                        <h6 class="card-title">Rating: &#x2605;&#x2605;&#x2605;&#x2606;&#x2606;</h6>
                    </div>
                    <div class="card-footer px-0">
                        <img class="img-fluid" src="/images/milk.jpg" alt="milk">
                    </div>
                </div>
                <div class="card card-block mx-2 col-lg-3 col-md-4 col-sm-6 col-8 text-center">
                    <div class="card-body px-0">
                        <router-link to="/product" class="stretched-link"></router-link>
                        <h3 class="card-title">Eggs 12 Pack</h3>
                        <h6 class="card-title">Was $1.99/kg</h6>
                        <h4 class="card-title">Now $0.99/kg</h4>
                        <h6 class="card-title">Rating: &#x2605;&#x2605;&#x2605;&#x2606;&#x2606;</h6>
                    </div>
                    <div class="card-footer px-0">
                        <img class="img-fluid" src="/images/eggs.jpg" alt="eggs">
                    </div>
                </div>
                <div class="card card-block mx-2 col-lg-3 col-md-4 col-sm-6 col-8 text-center">
                    <div class="card-body px-0">
                        <router-link to="/product" class="stretched-link"></router-link>
                        <h3 class="card-title">Carrots</h3>
                        <h6 class="card-title">Was $1.99/kg</h6>
                        <h4 class="card-title">Now $0.99/kg</h4>
                        <h6 class="card-title">Rating: &#x2605;&#x2605;&#x2605;&#x2606;&#x2606;</h6>
                    </div>
                    <div class="card-footer px-0">
                        <img class="img-fluid" src="/images/carrots.jpg" alt="carrots">
                    </div>
                </div>
                <div class="card card-block mx-2 col-lg-3 col-md-4 col-sm-6 col-8 text-center">
                    <div class="card-body px-0">
                        <router-link to="/product" class="stretched-link"></router-link>
                        <h3 class="card-title">Broccoli</h3>
                        <h6 class="card-title">Was $1.99/kg</h6>
                        <h4 class="card-title">Now $0.99/kg</h4>
                        <h6 class="card-title">Rating: &#x2605;&#x2605;&#x2605;&#x2606;&#x2606;</h6>
                    </div>
                    <div class="card-footer px-0">
                        <img class="img-fluid" src="/images/brocolli.jpg" alt="brocolli">
                    </div>
                </div>
                <div class="card card-block mx-2 col-lg-3 col-md-4 col-sm-6 col-8 text-center">
                    <div class="card-body px-0">
                        <router-link to="/product" class="stretched-link"></router-link>
                        <h3 class="card-title">Corn</h3>
                        <h6 class="card-title">Was $1.99/kg</h6>
                        <h4 class="card-title">Now $0.99/kg</h4>
                        <h6 class="card-title">Rating: &#x2605;&#x2605;&#x2605;&#x2606;&#x2606;</h6>
                    </div>
                    <div class="card-footer px-0">
                        <img class="img-fluid" src="/images/corn.jpg" alt="corn">
                    </div>
                </div>
                <div class="card card-block mx-2 col-lg-3 col-md-4 col-sm-6 col-8 text-center">
                    <div class="card-body px-0">
                        <router-link to="/product" class="stretched-link"></router-link>
                        <h3 class="card-title">Cheese and Bacon Shapes</h3>
                        <h6 class="card-title">Was $1.99/kg</h6>
                        <h4 class="card-title">Now $0.99/kg</h4>
                        <h6 class="card-title">Rating: &#x2605;&#x2605;&#x2605;&#x2606;&#x2606;</h6>
                    </div>
                    <div class="card-footer px-0">
                        <img class="img-fluid" src="/images/cheese-and-bacon-shapes.jpg" alt="cheese and bacon shapes">
                    </div>
                </div>
            </div>
        </div>

        <!--One of the articles you should expect to see in the article collection. If you expand the article, you'll see more of the article-->
        <div class="article-img">
            <div class="col-md-6 col-12" id="article-box">
                <h3>Egg-cellent Produce has reached 1 million weekly users!</h3>
                <p class="article-paragraph">Egg-cellent Produce now has over one million people who regularly shops at
                    our
                    stores and
                    online! That is approximately 4% of the population in Australia! We are incredibly
                    grateful to have this many people shopping with us! Thank you to all of those who
                    donated to our charity events! Without your support, we wouldn't be as big as we are
                    today! If you compare one million with Woolworths, well...they have approximately 20
                    million shoppers each week. Hopefully, we can overtake them in the future, but that's
                    just a dream.</p>
                <button type="button" class="btn p-1 px-2 rounded-pill border-0" data-bs-toggle="modal"
                    data-bs-target="#articleModal" id="btn-show-article">
                    Read more
                </button>
            </div>
        </div>

        <!-- Article modal. When the user clicks on the link in the footer, the modal appears and the reader can read it. I will consider finding a way to move this to an external file once I learn Vue -->
        <div class="modal modal-xl fade" id="articleModal" data-bs-backdrop="static" data-bs-keyboard="false"
            tabindex="-1" aria-labelledby="articleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-scrollable">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="home-img-modal">
                            <div id="article-paragraph-modal">
                                <h1 class="text-center">Egg-cellent Produce has reached 1 million weekly users!</h1>
                                <p>Egg-cellent Produce now has over one million people who regularly shops at our stores
                                    and
                                    online! That is approximately 4% of the population in Australia! We are incredibly
                                    grateful to have this many people shopping with us! Thank you to all of those who
                                    donated to our charity events! Without your support, we wouldn't be as big as we are
                                    today! If you compare one million with Woolworths, well...they have approximately 20
                                    million shoppers each week. Hopefully, we can overtake them in the future, but
                                    that's
                                    just a dream.</p>

                                <p>To cellebrate our milestone of reaching 1 million users, we will be selling our dairy
                                    products for 50% off! That's such a huge bargin! We have also updated our website
                                    with a
                                    more 'cozy' look, so if you're a regular shopper here, you will feel at home here!
                                    It's
                                    also a fresh new look for our website! Whether you like or don't like the new look,
                                    please give us feedback in the 'contact us' page so we can make adjustments based on
                                    your feedback! We hope to reach 2 million weekly users in the future!</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</template>