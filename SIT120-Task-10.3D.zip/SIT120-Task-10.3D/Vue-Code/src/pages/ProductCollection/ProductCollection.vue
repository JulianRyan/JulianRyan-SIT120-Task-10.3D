<script setup>
import './product-collection.css'
</script>

<template>
    <img id="page-banner" class="col-12 img-fluid" src="/images/banner-4.jpg" alt="banner">
    <!--A list of products under a category. In the future, I will add code to only display certain categories. -->
    <!-- Each item has a Title, a rating, a sale price and a current price, as well as an image -->
    <div class="px-0" id="product-content">
        <div class="row font-weight-light text-center  pt-4 pb-2 text-white mx-0">
            <h1>Meat Category</h1>
        </div>
        <div class="row mx-0 px-4 d-flex flex-wrap justify-content-center">
            <div class="card card-block text-center col-lg-3 col-md-4 col-sm-5 col-12 m-2 px-0 border-0">
                <div class="card-body px-1">
                    <router-link to="/product" class="stretched-link"></router-link>
                    <h3 class="card-title">Chicken Drumsticks 4-pack</h3>
                    <h6 class="card-title">Was $1.99/kg</h6>
                    <h4 class="card-title">Now $0.99/kg</h4>
                    <h6 class="card-title">Rating: &#x2605;&#x2605;&#x2605;&#x2606;&#x2606;</h6>
                </div>
                <div class="card-footer px-0">
                    <img class="img-fluid" src="/images/chicken-drumsticks-4.jpg" alt="chicken-drumsticks">
                </div>
            </div>
            <div class="card card-block text-center col-lg-3 col-md-4 col-sm-5 col-12 m-2 px-0 border-0">
                <div class="card-body px-1">
                    <router-link to="/product" class="stretched-link"></router-link>
                    <h3 class="card-title">Chicken Kiev</h3>
                    <h6 class="card-title">Was $1.99/kg</h6>
                    <h4 class="card-title">Now $0.99/kg</h4>
                    <h6 class="card-title">Rating: &#x2605;&#x2605;&#x2605;&#x2606;&#x2606;</h6>
                </div>
                <div class="card-footer px-0">
                    <img class="img-fluid" src="/images/chicken-kiev.jpg" alt="chicken kiev">
                </div>
            </div>
            <div class="card card-block text-center col-lg-3 col-md-4 col-sm-5 col-12 m-2 px-0 border-0">
                <div class="card-body px-1">
                    <router-link to="/product" class="stretched-link"></router-link>
                    <h3 class="card-title">Chicken Schnitzel</h3>
                    <h6 class="card-title">Was $1.99/kg</h6>
                    <h4 class="card-title">Now $0.99/kg</h4>
                    <h6 class="card-title">Rating: &#x2605;&#x2605;&#x2605;&#x2606;&#x2606;</h6>
                </div>
                <div class="card-footer px-0">
                    <img class="img-fluid" src="/images/chicken-schnitzel.jpg" alt="chicken schnitzel">
                </div>
            </div>
            <div class="card card-block text-center col-lg-3 col-md-4 col-sm-5 col-12 m-2 px-0 border-0">
                <div class="card-body px-1">
                    <router-link to="/product" class="stretched-link"></router-link>
                    <h3 class="card-title">Pork loin</h3>
                    <h6 class="card-title">Was $1.99/kg</h6>
                    <h4 class="card-title">Now $0.99/kg</h4>
                    <h6 class="card-title">Rating: &#x2605;&#x2605;&#x2605;&#x2606;&#x2606;</h6>
                </div>
                <div class="card-footer px-0">
                    <img class="img-fluid" src="/images/pork-loin.jpg" alt="pork loin">
                </div>
            </div>
            <div class="card card-block text-center col-lg-3 col-md-4 col-sm-5 col-12 m-2 px-0 border-0">
                <div class="card-body px-1">
                    <router-link to="/product" class="stretched-link"></router-link>
                    <h3 class="card-title">Pork mince</h3>
                    <h6 class="card-title">Was $1.99/kg</h6>
                    <h4 class="card-title">Now $0.99/kg</h4>
                    <h6 class="card-title">Rating: &#x2605;&#x2605;&#x2605;&#x2606;&#x2606;</h6>
                </div>
                <div class="card-footer px-0">
                    <img class="img-fluid" src="/images/pork-mince.jpg" alt="pork mince">
                </div>
            </div>
            <div class="card card-block text-center col-lg-3 col-md-4 col-sm-5 col-12 m-2 px-0 border-0">
                <div class="card-body px-1">
                    <router-link to="/product" class="stretched-link"></router-link>
                    <h3 class="card-title">Beef patties 4-pack</h3>
                    <h6 class="card-title">Was $1.99/kg</h6>
                    <h4 class="card-title">Now $0.99/kg</h4>
                    <h6 class="card-title">Rating: &#x2605;&#x2605;&#x2605;&#x2606;&#x2606;</h6>
                </div>
                <div class="card-footer px-0">
                    <img class="img-fluid" src="/images/beef-patties-4.jpg" alt="beef patties">
                </div>
            </div>
            <div class="card card-block text-center col-lg-3 col-md-4 col-sm-5 col-12 m-2 px-0 border-0">
                <div class="card-body px-1">
                    <router-link to="/product" class="stretched-link"></router-link>
                    <h3 class="card-title">Beef patties 6-pack</h3>
                    <h6 class="card-title">Was $1.99/kg</h6>
                    <h4 class="card-title">Now $0.99/kg</h4>
                    <h6 class="card-title">Rating: &#x2605;&#x2605;&#x2605;&#x2606;&#x2606;</h6>
                </div>
                <div class="card-footer px-0">
                    <img class="img-fluid" src="/images/beef-patties-6.jpg" alt="beef patties 2">
                </div>
            </div>
            <div class="card card-block text-center col-lg-3 col-md-4 col-sm-5 col-12 m-2 px-0 border-0">
                <div class="card-body px-1">
                    <router-link to="/product" class="stretched-link"></router-link>
                    <h3 class="card-title">Lamb chops 4-pack</h3>
                    <h6 class="card-title">Was $1.99/kg</h6>
                    <h4 class="card-title">Now $0.99/kg</h4>
                    <h6 class="card-title">Rating: &#x2605;&#x2605;&#x2605;&#x2606;&#x2606;</h6>
                </div>
                <div class="card-footer px-0">
                    <img class="img-fluid" src="/images/lamb-chops-4.jpg" alt="lamb chops">
                </div>
            </div>
            <div class="card card-block text-center col-lg-3 col-md-4 col-sm-5 col-12 m-2 px-0 border-0">
                <div class="card-body px-1">
                    <router-link to="/product" class="stretched-link"></router-link>
                    <h3 class="card-title">Lamb chops 6-pack</h3>
                    <h6 class="card-title">Was $1.99/kg</h6>
                    <h4 class="card-title">Now $0.99/kg</h4>
                    <h6 class="card-title">Rating: &#x2605;&#x2605;&#x2605;&#x2606;&#x2606;</h6>
                </div>
                <div class="card-footer px-0">
                    <img class="img-fluid" src="/images/lamb-chops-6.jpg" alt="lamb chops 2">
                </div>
            </div>
            <div class="card card-block text-center col-lg-3 col-md-4 col-sm-5 col-12 m-2 px-0 border-0">
                <div class="card-body px-1">
                    <router-link to="/product" class="stretched-link"></router-link>
                    <h3 class="card-title">Pork fillet</h3>
                    <h6 class="card-title">Was $1.99/kg</h6>
                    <h4 class="card-title">Now $0.99/kg</h4>
                    <h6 class="card-title">Rating: &#x2605;&#x2605;&#x2605;&#x2606;&#x2606;</h6>
                </div>
                <div class="card-footer px-0">
                    <img class="img-fluid" src="/images/pork-fillet.jpg" alt="pork fillet">
                </div>
            </div>
            <div class="card card-block text-center col-lg-3 col-md-4 col-sm-5 col-12 m-2 px-0 border-0">
                <div class="card-body px-1">
                    <router-link to="/product" class="stretched-link"></router-link>
                    <h3 class="card-title">Salmon</h3>
                    <h6 class="card-title">Was $1.99/kg</h6>
                    <h4 class="card-title">Now $0.99/kg</h4>
                    <h6 class="card-title">Rating: &#x2605;&#x2605;&#x2605;&#x2606;&#x2606;</h6>
                </div>
                <div class="card-footer px-0">
                    <img class="img-fluid" src="/images/salmon.jpg" alt="salmon">
                </div>
            </div>
            <div class="card card-block text-center col-lg-3 col-md-4 col-sm-5 col-12 m-2 px-0 border-0">
                <div class="card-body px-1">
                    <router-link to="/product" class="stretched-link"></router-link>
                    <h3 class="card-title">Mongolian Beef</h3>
                    <h6 class="card-title">Was $1.99/kg</h6>
                    <h4 class="card-title">Now $0.99/kg</h4>
                    <h6 class="card-title">Rating: &#x2605;&#x2605;&#x2605;&#x2606;&#x2606;</h6>
                </div>
                <div class="card-footer px-0">
                    <img class="img-fluid" src="/images/beef.jpg" alt="beef">
                </div>
            </div>
        </div>

        <!--Will add functionality to view 8-12 more items before the button reappears at the bottom of the collection of items. -->
        <div class="row mx-0 px-4">
            <div class="text-center my-4">
                <button type="button" class="btn p-1 px-2 mx-2 rounded-pill border-0" id="btn-view-more">
                    View more
                </button>
            </div>
        </div>
    </div>
</template>