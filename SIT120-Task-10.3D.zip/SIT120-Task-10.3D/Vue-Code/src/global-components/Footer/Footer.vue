<script setup>
import PrivacyPolicy from '../PrivacyPolicyModal/PrivacyPolicy.vue';
import TermsAndConditions from '../TermsAndConditionsModal/TermsAndConditions.vue';
import './footer.css'
</script>

<template>
    <footer>
        <div class="container-fluid row bg-info-subtle pb-2 mx-0" id="footer">
            <div class="col-6 text-center">
                <h4 class="footer-title my-0 pt-1">Need Help?</h4>
                <!--Link to Contact Us Page-->
                <p class="my-0"><a href="contact-us.html" class="footer-links">Contact Us</a></p>
                <p class="my-0"><a href="contact-us.html" class="footer-links">Help</a></p>
                <p class="my-0"><a href="contact-us.html" class="footer-links">FAQs</a></p>
                <p class="my-0"><a href="" data-bs-toggle="modal" data-bs-target="#termsAndConditionsModal"
                        class="footer-links">Terms and Conditions</a></p>
                <p class="my-0"><a href="" data-bs-toggle="modal" data-bs-target="#privacyPolicyModal"
                        class="footer-links">Privacy Policy</a></p>
            </div>
            <div class="col-6 text-center">
                <h4 class="footer-title my-0 pt-1">Learn more about us!</h4>
                <!--Link to About Us Page-->
                <p class="my-0"><a href="about-us.html" target="_blank" class="footer-links">About Us</a></p>
                <!--Links to Social Media Pages. Since there will be no scial media sites they will be linked to a blank page -->
                <p class="my-0">
                    <a href="https://www.facebook.com" class="fa fa-facebook footer-links px-2"></a>
                    <a href="https://www.twitter.com" class="fa fa-twitter footer-links px-2"></a>
                    <a href="https://www.youtube.com" class="fa fa-youtube footer-links px-2"></a>
                    <a href="https://www.instagram.com" class="fa fa-instagram footer-links px-2"></a>
                </p>
            </div>
        </div>
        <div class="p-2 text-center text-white" id="copyright">
            © Egg-cellent Produce, <a href="mailto: jcryan@deakin.edu.au" target="_blank" class="footer-email">Email:
                jcryan@deakin.edu.au</a>, Last Updated: 13/09/2024
        </div>
        <!-- Privacy modal. When the user clicks on the link in the footer, the modal appears and the reader can read it. I will consider finding a way to move this to an external file once I learn Vue -->
        <TermsAndConditions :id="'termsAndConditionsModal'"/>
        <PrivacyPolicy :id="'privacyPolicyModal'"/>
    </footer>
</template>