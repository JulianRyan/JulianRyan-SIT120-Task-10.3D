<script setup>
import Home from './pages/Home/Home.vue';
import AboutUs from './pages/AboutUs/AboutUs.vue';
import ArticleCollection from './pages/ArticleCollection/ArticleCollection.vue';
import Checkout from './pages/Checkout/Checkout.vue';
import ContactUs from './pages/ContactUs/ContactUs.vue';
import Product from './pages/Product/Product.vue';
import ProductCollection from './pages/ProductCollection/ProductCollection.vue';
import Header from './global-components/Header/Header.vue';
import Footer from './global-components/Footer/Footer.vue';

</script>

<!-- Link for routing: https://pasankamburugamuwa1.medium.com/vue-router-building-multi-page-single-applications-26b52cc6125e -->
<template>
  <Header />
  <router-view></router-view>
  <Footer />
</template>
